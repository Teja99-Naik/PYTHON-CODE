


pi = 22 / 7
print("Value of pi:", pi)
print("Type of pi:", type(pi))



for_variable = 4
print("Value of for_variable:", for_variable)



P = 10000  # Principal amount
R = 5      # Rate of interest
T = 2      # Time in years

simple_interest = (P * R * T) / 100
print("Simple Interest:", simple_interest)